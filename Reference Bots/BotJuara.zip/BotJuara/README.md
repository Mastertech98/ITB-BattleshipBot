# Python3

## py3Bot

Python 3 standard library. Never attacks the same square twice. 
Simplified and partially plagiarized version of Christian's Python2 bot.
